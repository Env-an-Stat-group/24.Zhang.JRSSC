#!/bin/csh
#$ -M jzhang19@nd.edu
#$ -m ae
#$ -pe smp 1
#$ -q long
#$ -N gaus_Stationary_with_land_sea_effect
#$ -t 1-4

module purge
module load R/4.2.0/gcc/8.5.0 gdal geos udunits
Rscript post_test_gaus_Stationary_with_land_sea.R
