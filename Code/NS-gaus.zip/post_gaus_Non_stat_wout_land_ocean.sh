#!/bin/csh
#$ -M jzhang19@nd.edu
#$ -m ae
#$ -pe smp 1
#$ -q long
#$ -N posterior_test_gaussian_Nonstationary_without_land_ocean_effect
#$ -t 1-8

module purge
module load R/4.2.0/gcc/8.5.0 gdal geos udunits
Rscript post_gaus_Non_stat_wout_land_ocean.R
