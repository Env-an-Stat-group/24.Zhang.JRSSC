#!/bin/csh
#$ -M yqiu4@nd.edu
#$ -m ae
#$ -pe smp 1
#$ -q long
#$ -N gaus_NS_smallmdf
#$ -t 1-8

module purge
module load R/4.2.0/gcc/8.5.0 gdal geos udunits
Rscript taucs_test_posterior.R
