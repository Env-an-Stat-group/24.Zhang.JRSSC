#!/bin/csh
#$ -M jzhang19@nd.edu
#$ -m ae
#$ -pe smp 1
#$ -q long
#$ -N post_test_gaus_Stationary_without_land_ocean_effect
#$ -t 1-4

module purge
module load R/4.2.0/gcc/8.5.0 gdal geos udunits
Rscript post_gaus_Stationary_wout_land_ocean.R
